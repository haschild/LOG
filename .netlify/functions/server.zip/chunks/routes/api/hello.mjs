const hello = async (req, res) => {
  const data = {
    msg: "hello 2"
  };
  JSON.stringify(data);
  return data;
};

export { hello as default };
//# sourceMappingURL=hello.mjs.map
