import process from 'node:process';globalThis._importMeta_={url:import.meta.url,env:process.env};export { I as handler } from './chunks/runtime.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import '@iconify/utils';
import 'consola/core';
//# sourceMappingURL=server.mjs.map
